from __future__ import unicode_literals

from django.apps import AppConfig


class UsernameAppConfig(AppConfig):
    name = 'username_app'
