from django.shortcuts import render, redirect
from .models import League, Team, Player
from django.db.models.functions import Coalesce

from . import team_maker

def index(request):
	# currplay = Team.objects.get(location="Wichita", team_name="Vikings").curr_players.all()
	# print currplay
	large_team_list = []
	large_teams = Team.objects.all()
	for team in large_teams:
		if team.all_players.all().count() > 12:
			large_team_list.append(team.team_name)

	context = {
		"leagues": League.objects.all(),
		"teams": Team.objects.all(),
		"players": Player.objects.all().order_by('first_name'),
		"asc_teams": Team.objects.filter(league=League.objects.get(name="Atlantic Soccer Conference")),
		"bostonp_players": Player.objects.filter(curr_team=Team.objects.get(team_name="Penguins")),
		"icbc_players" : League.objects.get(name="International Collegiate Baseball Conference").teams.all(),
		"acaf_players" : League.objects.get(name="American Conference of Amateur Football").teams.all(),
		"football_players" : League.objects.filter(sport="Football"),
		"sophia_teams" : Player.objects.filter(first_name="Sophia"),
		"flores": Team.objects.all().exclude(location="Washington", team_name="Roughriders"),
		"sams_teams": Team.objects.all(),
		"team_manitoba" : Team.objects.get(location="Manitoba", team_name="Tiger-Cats"),
		"viking_players" : Team.objects.get(location="Wichita", team_name="Vikings"),
		#would use .exclude(currplay) however currplay is returning an empty set
		"jacob_gray" : Team.objects.all(),
		"joshua" : League.objects.get(name="Atlantic Federation of Amateur Baseball Players").teams.all(),
		"large_teams": large_team_list,
		"players_counter": Player.objects.all().order_by('all_teams')
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
